/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    private double mean;
    private double stddev;
    private double confidenceLo;
    private double confidenceHi;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n <= 0) throw new IllegalArgumentException("n <= 0 !");
        if (trials <= 0) throw new IllegalArgumentException("trials <= 0 !");

        {
            double[] results = new double[trials];
            for (int i = 0; i < trials; i++) {
                Percolation p = new Percolation(n);
                while (p.numberOfOpenSites() < n) {
                    p.open(StdRandom.uniform(1, n), StdRandom.uniform(1, n));
                    if (p.percolates()) break;
                }
                results[i] = (double) p.numberOfOpenSites() / n;
                trials--;
            }
            mean = StdStats.mean(results);
            stddev = StdStats.stddev(results);
            confidenceLo = mean - 1.96 * stddev / Math.sqrt(trials);
            confidenceHi = mean + 1.96 * stddev / Math.sqrt(trials);
        }
    }

    // sample mean of percolation threshold
    public double mean() {
        return mean;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return stddev;
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return confidenceLo;
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return confidenceHi;
    }

    // test client (see below)
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int T = Integer.parseInt(args[1]);
        PercolationStats stats = new PercolationStats(n, T);
        System.out.printf("mean                     = %s%n", stats.mean);
        System.out.printf("stddev                   = %s%n", stats.stddev);
        System.out.printf("95%% confidence interval = [%1$s, %2$s]",
                          stats.confidenceLo(),
                          stats.confidenceHi());
    }
}
