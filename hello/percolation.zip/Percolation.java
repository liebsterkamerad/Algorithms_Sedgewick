/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    private Site[][] sites;
    private WeightedQuickUnionUF uf;
    private int n;
    private int numberOfOpenSites = 0;
    private int topVirtualIndex;
    private int bottomVirtualIndex;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) throw new IllegalArgumentException("n <= 0 is not allowed!");
        this.n = n;
        this.sites = new Site[n][n];
        this.uf = new WeightedQuickUnionUF(n * n + 2); // plus 2 virtual sites for top and bottom
        this.topVirtualIndex = 0;
        this.bottomVirtualIndex = n + 1;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                sites[i][j] = new Site();
            }
        }

        // connect top row sites to the top virtual site
        for (int col = 1; col <= n; col++) {
            uf.union(topVirtualIndex, getUFIndex(1, col));
        }

        // connect bottom row sites to the bottom virtual site
        for (int col = 1; col <= n; col++) {
            uf.union(topVirtualIndex, getUFIndex(n, col));
        }
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        validate(row, col);
        Site site = getSite(row, col);
        if (!site.isOpen()) {
            site.setOpen(true);
            numberOfOpenSites++;
            int currentSiteIndex = getUFIndex(row, col);
            if (row > 1)
                uf.union(currentSiteIndex, getUFIndex(row - 1, col));
            if (row < n)
                uf.union(currentSiteIndex, getUFIndex(row + 1, col));
            if (col > 1)
                uf.union(currentSiteIndex, getUFIndex(row, col - 1));
            if (col < n)
                uf.union(currentSiteIndex, getUFIndex(row, col + 1));
            if (uf.find(topVirtualIndex) == currentSiteIndex)
                site.setFull(true);
        }
    }

    private Site getSite(int row, int col) {
        return sites[row - 1][col - 1];
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        validate(row, col);
        return getSite(row, col).isOpen();
    }

    private void validate(int row, int col) {
        if (row < 1 || row > n)
            throw new IllegalArgumentException(
                    "Row index is outside allowed range (1, n)!");
        if (col < 1 || col > n)
            throw new IllegalArgumentException(
                    "Column index is outside allowed range (1, n)!");
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        validate(row, col);
        return getSite(row, col).isFull();
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return numberOfOpenSites;
    }

    // does the system percolate?
    public boolean percolates() {
        return findTopVirtualSite() == findBottomVirtualSite();
    }

    private int getUFIndex(int row, int col) {
        // plus 1 for virtual top site having index 0
        return (col - 1) + (row - 1) * n + 1;
    }

    private int findBottomVirtualSite() {
        return uf.find(n + 1);
    }

    private int findTopVirtualSite() {
        return uf.find(0);
    }

    private class Site {
        private boolean open = false;
        private boolean full = false;

        public boolean isOpen() {
            return open;
        }

        public void setOpen(boolean open) {
            this.open = open;
        }

        public void setFull(boolean full) {
            this.full = full;
        }

        public boolean isFull() {
            return this.full;
        }
    }

    // test client (optional)
    public static void main(String[] args) {
        Percolation p = new Percolation(3);
        p.getSite(2, 2);
        System.out.println(p.percolates());
    }
}